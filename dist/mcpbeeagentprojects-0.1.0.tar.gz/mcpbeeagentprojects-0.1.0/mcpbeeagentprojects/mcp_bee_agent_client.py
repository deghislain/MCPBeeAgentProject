import streamlit as st
from mcp_bee_agent_tools import StockTools as tool


def main() -> None:
    tool.get_income_statement_info(symbol)


if __name__ == "__main__":
    print('*************************')
    symbol = st.text_input(':blue[Enter a stock symbol:]')
    st.button("Submit")
    if symbol:
        main()
