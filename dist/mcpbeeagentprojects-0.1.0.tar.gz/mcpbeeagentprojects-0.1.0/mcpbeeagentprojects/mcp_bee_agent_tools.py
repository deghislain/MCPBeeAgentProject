from typing import List, Dict
from utils import create_income_statement
import requests
import os

AV_STOCK_API_KEY = os.environ.get('AV_STOCK_API_KEY')


class StockTools:

    def get_income_statement_info(stock_symbol: str) -> List[Dict]:
        """
           Retrieves the income statements info for a given stock for the last 3 years'

           Args:
               stock_symbol: The stock symbol, e.g., "IBM".

           Returns:
               A set of dictionary containing the income statements info for a given stock for the last 3 years
           """
        print(f"Getting last year net income for {stock_symbol}")
        try:
            income_statement_info = {}
            stock_url = f"https://www.alphavantage.co/query?function=INCOME_STATEMENT&symbol={stock_symbol}&apikey={AV_STOCK_API_KEY}"
            stock_data = requests.get(stock_url)
            return create_income_statement(stock_data)

        except Exception as e:
            print(f"Error fetching stock data: {e}")
            return []

