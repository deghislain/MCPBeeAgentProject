import tomllib
from pathlib import Path
import yaml


def load_config(section: str | None = None) -> dict:
    config = tomllib.loads((Path(__file__).parent / "config.toml").read_text())
    if section is not None:
        return config[section]
    else:
        return config


def read_yaml_file(file_path):
    """
    Reads a YAML file from the given file path and returns its content as a Python dictionary.

    :param file_path: The path to the YAML file on the disk.
    :return: A Python dictionary interpreting the content of the YAML file.
    """
    try:
        with open(file_path, 'r') as file:
            # Use yaml.safe_load() to parse the YAML file into a Python dictionary
            parsed_dict = yaml.safe_load(file)
        return parsed_dict
    except FileNotFoundError:
        raise FileNotFoundError(f"The file at path '{file_path}' was not found.")
    except Exception as e:
        raise ValueError(f"Error reading YAML file: {e}")


def create_income_statement(stock_data):
    """
    Retrieves income statement for the last consecutive 3 years from a JSON object
    and returns a list of dictionaries representing each year.

    Args:
        stock_data (object): Object containing JSON data with annual reports.

    Returns:
        list: List of dictionaries, each representing an income statement for a year.
    """
    annual_reports = stock_data.json()["annualReports"]
    income_statement_keys = [
        'Fiscal Date Ending',
        'Reported Currency',
        'Gross Profit',
        'Total Revenue',
        'Cost of Revenue',
        'Cost of Goods and Services Sold',
        'Operating Income',
        'Selling General and Administrative',
        'Research and Development',
        'Operating Expenses',
        'Investment Income Net',
        'Net Interest Income',
        'Interest Income',
        'Interest Expense',
        'Non-Interest Income',
        'Other Non-Operating Income',
        'Depreciation',
        'Depreciation and Amortization',
        'Income Before Tax',
        'Income Tax Expense',
        'Interest and Debt Expense',
        'Net Income from Continuing Operations',
        'Comprehensive Income Net of Tax',
        'EBIT',
        'EBITDA',
        'Net Income'
    ]

    income_statements = []
    for report in annual_reports[:3]:  # Get the last 3 annual reports
        income_statement = {key: report[key] for key in income_statement_keys}
        income_statements.append(income_statement)

    return income_statements

